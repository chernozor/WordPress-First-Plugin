=== My Plugin ===
Contributors: Webmaster Gambit
Tags: pattern, plugin, module, wordpress
Requires at least: 3.0.1
Tested up to: 4.5.3
Stable tag: 1.0.0

My Plugin - бесплатный шаблон плагина пустышки для WordPress CMS.

== Description ==

Предназначен для ознакомления со структурой модуля WordPress. Модуль пустышка. Используйте его, если необходимо написать новый модуль для WordPress.

Имеет:
- Ссылки на страницу настроек и сайт разработчка в Панели Администратора;
- Структуру согласно официальной документации WordPress;
- Два параметра в настройках плагина;
- Третий параметр рассчитывается как сумма первых двух;

== Installation ==
1. Выберите Плагины -> Добавить новый -> Загрузить.
2. Выберите .zip архив плагина *myPlugin*.
3. Установите плагин *myPlugin* и активируйте его.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==
= 1.0.0 =
* Первая версия плагина