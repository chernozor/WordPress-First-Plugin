=== My First Plugin ===
Contributors: Webmaster Gambit
Tags: pattern, plugin, module, wordpress, example
Requires at least: 3.0.1
Tested up to: 4.7
Stable tag: 1.0.0

My First Plugin - пример простого плагина пустышки для WordPress CMS

== Description ==

My First Plugin предназначен для ознакомления со структурой плагина WordPress.
"Модуль пустышка" - используйте его, если необходимо написать новый модуль для WordPress.

Имеет:
- Ссылки на страницу настроек и сайт разработчка в Панели Администратора;
- Корректную структуру плагина для WordPress;
- Два основных параметра в настройках плагина;
- Дополнительный параметр, который рассчитывается как сумма двух основных параметров;
- Страница настроек в меню администратора с логотипом плагина;

== Installation ==
1. Выберите Плагины -> Добавить новый -> Загрузить.
2. Выберите .zip архив плагина *MyFirstPlugin*.
3. Установите плагин *MyFirstPlugin* и активируйте его.

== Frequently Asked Questions ==
***

== Screenshots ==
***

== Changelog ==
= 1.0.0 =
* Release